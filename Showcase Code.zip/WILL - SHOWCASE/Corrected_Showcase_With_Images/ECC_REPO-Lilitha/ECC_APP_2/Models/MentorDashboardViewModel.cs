﻿namespace ECC_APP_2.Models
{
    public class MentorDashboardViewModel
    {
        public List<BussinessProposalTemplate> BusinessProposals { get; set; }
        public List<FundingGuideTemplate> FundingGuides { get; set; }

    }
}
