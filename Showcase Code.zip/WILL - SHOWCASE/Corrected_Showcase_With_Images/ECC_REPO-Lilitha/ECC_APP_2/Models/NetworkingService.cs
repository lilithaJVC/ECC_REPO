﻿namespace ECC_APP_2.Models
{
    public class NetworkingService
    {

    }
}
