﻿namespace ECC_APP_2.Views.Home
{
    public class StudentRepository
    {
    }
}
