﻿using Microsoft.AspNetCore.Mvc;

namespace ECC_APP_2.Controllers
{
    public class FundingGuideTemplateController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
