﻿using Microsoft.AspNetCore.Mvc;

namespace ECC_APP_2.Controllers
{
    public class AdministratorCntroller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //public int id { get; set; }
    }
}
